<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$value=$_POST['que'];
	$_SESSION['value'] = $value;
	$result=mysql_query("SELECT * FROM ".$value."_questions ");
	$i=0;
	while($row=mysql_fetch_array($result))
	{
		$_SESSION['question['.$i.']'] = $row['question'];
		$i++;
	}
	header('Location:questions.php')
?>
