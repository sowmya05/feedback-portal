$(document).ready(function() {		
				var options = {
	            			chart: {
	                			renderTo: 'graph',
	                			type: 'bar'
	            				},
	            			title: {
	                			text: 'Progress',
	                			x: -20 //center
	            				},
	            			subtitle: {
	                			text: '',
	                			x: -20
	            				},
	            			xAxis: {
	                			categories: []
	            				},
	            			yAxis: {
	                			min: 0,
	                			title: {
	                    			text: 'Average Over Years'
	                			},
	                		labels: {
	                    			overflow: 'justify'
	                			}
	            			     },
	            		tooltip: {
	                		formatter: function() {
	                        	return '<b>'+ this.series.name +'</b><br/>'+
	                        	this.x +': '+ this.y;
	                		}
	            		},
	            	legend: {
	                	layout: 'vertical',
	                	align: 'right',
	                	verticalAlign: 'top',
	                	x: -10,
	                	y: 100,
	                	borderWidth: 0
	           		}, 
	            	plotOptions: {
	                	bar: {
			            dataLabels: {
			                enabled: true
			            }
			        }
			    },
			    series: []
			}
		
	        
			$.getJSON("graph.php", function(json) {
					options.xAxis.categories = json[0]['data'];
				options.series[0] = json[1];
				chart = new Highcharts.Chart(options);
			});
		    });
