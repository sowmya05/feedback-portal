<!DOCTYPE html>
<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	//echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$result = mysql_query("SELECT * FROM disable");
	$row = mysql_fetch_array($result);
	$get = $row['enable'];
?>
<html>
<head>
	<link type="text/css" rel="stylesheet" href="admin.css"/>
</head>
<body>
<div id="body">
<h3>Feedback Portal</h3>
<button onclick="location.href='../main_page.php'" class="back">Logout</button>
<div id="buttons">
<p>To View and Edit Questions: </p>
<button onclick="location.href='questions.php'">view and edit questions</button>
<p>To View Feedback: </p>
<button onclick="location.href='feedback.php'">View feedback</button>
<p>To Enable/Disable Feedback: </p>
<button onclick="location.href='disable.php'"><?php if($get=='yes') echo 'Disable feedback'; else echo 'Enable Feedback';?></button>
</div>
</div>
</body>
</html>

