<!DOCTYPE html>
<?php
session_start();
$value = $_SESSION['value'];
$i=0;
while($_SESSION['question['.$i.']'])
{
$question[$i] = $_SESSION['question['.$i.']'];
$i++;
}
session_unset();
?>
<html>
<head>
	<script type='text/javascript' src='a.js'></script>
	<link type="text/css" rel="stylesheet" href="admin.css"/>
</head>
<body>
	<script type="text/javascript">
		function func(){
		location.href = 'add_que.php';
		}
	</script>
	<script type='text/javascript'>

	 $(document).ready(function() { 
	   $('input[name=que]').change(function(){
		$('#a').submit();
	   });
	  });

	</script>
	<div id="body">
	<h3>Feedback Portal</h3>
	<button onclick="location.href='admin_page.php'" class="back">BACK</button>
	<div id="buttons">
	<form name="value" action="get_value.php" method=POST id="a">
	<input type=radio value="course" id="course" name="que" <?php if($value=='course') echo 'checked="checked"'; ?>><label for="course" >Course</label>
	<input type=radio value="instructor" id="instructor" name="que" <?php if($value=='instructor') echo 'checked="checked"'; ?>><label for="instructor">Instructor</label>
	<input type=radio value="lab" id="lab" name="que" <?php if($value=='lab') echo 'checked="checked"'; ?>><label for="lab" >Lab</label>
	<input type=radio value="tutorial" id="tutorial" name="que" <?php if($value=='tutorial') echo 'checked="checked"'; ?>><label for="tutorial">Tutorial</label>	
	</form>

	<div>
		<?php
			$i=0;
			while($question[$i]){
				echo '<form name="delete" action="delete.que.php" method="POST">';
				echo '<div>&nbsp;</div>';
				$j = $i+1;
				echo $j;
				echo '. ';
				echo $question[$i];
				echo '<input type=text value="'.$question[$i].'" hidden="true" name="questions">';
				echo '<input type=text value='.$value.' hidden="true" name="value">';
				echo '<input type=submit value=Delete class="delete"></form>';
				$i++;
			}
			if($value) {
			echo '<form action="add_que.php" method="POST"><div>&nbsp;</div><textarea name="question" cols=80></textarea>';
			
			echo '<input type=text value='.$value.' name="value" hidden="true">';
			echo '<div>&nbsp;</div>';			
			echo '<input type="submit" value="add question"></form>';
			 } 
			
			?>
			
	</div>
	</div>
	</div>
</body>
</html>
