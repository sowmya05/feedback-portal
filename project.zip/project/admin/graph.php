<?php
session_start();
$username = "root";
$password = "mysql";
$hostname = "localhost"; 
//connection to the database
$dbhandle = mysql_connect($hostname, $username, $password)
  or die("Unable to connect to MySQL");
$selected=mysql_select_db("working",$dbhandle)
 or die("could not select working");
$name = $_SESSION['get'];
$post = $_SESSION['post'];
if($post=='faculty')
	$query = mysql_query("SELECT year,avg FROM faculty_year WHERE webmail = '$name'");
else
	$query = mysql_query("SELECT year,avg FROM ".$post."_year WHERE course = '$name'");

$category = array();
$category['name'] = 'YEAR';

$series1 = array();
$series1['name'] = 'AVERAGE';

while($r = mysql_fetch_array($query)) {
    $category['data'][] = $r['year'];
    $series1['data'][] = $r['avg'];
}

$result = array();
array_push($result,$category);
array_push($result,$series1);

print json_encode($result, JSON_NUMERIC_CHECK);

mysql_close($dbhandle);
?>
