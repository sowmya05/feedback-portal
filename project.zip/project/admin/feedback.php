<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	//echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$value = $_SESSION['value'];
	$name = $_SESSION['name'];
	session_unset();
?>
<!DOCTYPE html>
<html>
<head>
		<link type="text/css" rel="stylesheet" href="page2.css"/>
		<link type="text/css" rel="stylesheet" href="admin.css"/>
		<script type="text/javascript" src="jquery.min.js"></script>
		<script type="text/javascript" src="graph.js"></script>
	    	<script src="highcharts.js"></script>
        	<script src="exporting.js"></script>	
<head>
<body>
	<div id="body">
	<h3>Feedback Portal</h3>
	<button onclick="location.href='admin_page.php'" class="back">BACK</button>
	<div id="buttons">
	<form action="option.php" id="option" method="POST">
	 <label for="select">Choose an option: </label>
	 <select name="select" id="select" form="option" onchange="this.form.submit()">
		<option value="course">Choose</option>
  		<option value="course" <?php if($value=='course') echo 'selected="selected"'?>>Course Feedback</option>
  		<option value="faculty" <?php if($value=='faculty') echo 'selected="selected"'?>>Faculty Feedback</option>
  		<option value="lab" <?php if($value=='lab') echo 'selected="selected"'?>>Lab Feedback</option>
  		<option value="tutorial" <?php if($value=='tutorial') echo 'selected="selected"'?>>Tutorial Feedback</option>
	</select>
	</form> 
	<div>
		<?php
			if($value!=NULL && $name==NULL){
			echo '<form action="value.php" method="POST">';
			echo '<label for="text">';
			if($value=='course') echo 'Enter course Code';
			else if($value=='faculty') echo 'Enter webmail id of faculty';
			else if($value=='lab') echo 'Enter course Code';
			else if($value=='tutorial') echo 'Enter course code';
			echo '<input type=text name="value" value="'.$value.'" hidden="hidden">';
			echo '<input type="text" id="text" name="text">';
			echo '<input type="submit" value="submit">';
			}
			$_SESSION['get']=$name;
			$_SESSION['post']=$value;
		?>
	</div>

	<div>
		<?php
			if($value!=NULL && $name!=NULL){
				if($value=='faculty'){
					$result = mysql_query("SELECT * FROM faculty_total_avg WHERE webmail = '$name'");
					$row = mysql_fetch_array($result);
					$total_avg = $row['avg'] * 20;
					$result = mysql_query("SELECT * FROM faculty WHERE webmail = '$name'");
					if(mysql_num_rows($result)==0)
					{
						echo '<script>alert("Something went wrong!");
							</script>';
						header('Location:feedback.php');
					}
					$i=0;
					while($row = mysql_fetch_array($result))
					{
						$name1 = $row['faculty'];
						$course[$i] = $row['course'];
						$result1 = mysql_query("SELECT * FROM faculty_avg WHERE webmail = '$name' AND course = '$course[$i]'");
						$row1=mysql_fetch_array($result1);
						$avg[$i] = $row1['avg'] * 20;
						$i++;
					}
					
					echo '<h4>'.$name1.'   
					<div class="rating_bar">
						<div  class="rating" style="width:'.$total_avg.'%;">
						</div>
					</div></h4>
				
					<div class="header" id="courses">
						<h2>Your courses: </h2>';
						$i=0; foreach ($course as $j) {
						echo	'<p>'.$j.'</p>
							<div class="rating_bar">
							    <div  class="rating" style="width:'.$avg[$i].'%;">
							    </div>
							</div>';
							$i++;
							}
						
				echo'	</div>
			
					<div id="graph" ></div>';
				}
				else {
					$result = mysql_query("SELECT * FROM ".$value."_avg WHERE course = '$name'");
					if(mysql_num_rows($result)==0)
					{
						echo '<script>alert("Something went wrong!");
							</script>';
						header('Location:feedback.php');
					}
					$row = mysql_fetch_array($result);
					$total_avg = $row['avg'] * 20;
					echo '<h4>'.$name.'   
					<div class="rating_bar">
						<div  class="rating" style="width:'.$total_avg.'%;">
						</div>
					</div></h3>';
				
					echo '<div id="graph" ></div>';
				}
			}
		?>
	</div>
		<?php
			if($value!=NULL && $name!=NULL){
				if($value=='faculty'){
					$result=mysql_query("SELECT * FROM faculty_feedback WHERE webmail='$name'");
					$zero=0;$one=0;$two=0;$three=0;$four=0;$five=0;
					while($row=mysql_fetch_array($result))
					{
						$zero = $zero + $row['zero'];
						$one = $one + $row['one'];
						$two = $two + $row['two'];
						$three = $three + $row['three'];
						$four = $four + $row['four'];
						$five = $five + $row['five'];
					}
					echo '<p>Unable to Judge : '.$zero.'</p>';
					echo '<p>Strongly Disagree : '.$one.'</p>';
					echo '<p>Disagree : '.$two.'</p>';
					echo '<p>Neutral : '.$three.'</p>';
					echo '<p>Agree : '.$four.'</p>';
					echo '<p>Strongly Agree : '.$zero.'</p>';
				}
				else {
					$result=mysql_query("SELECT * FROM ".$value."_feedback WHERE webmail='$name'");
					$zero=0;$one=0;$two=0;$three=0;$four=0;$five=0;
					while($row=mysql_fetch_array($result))
					{
						$zero = $zero + $row['zero'];
						$one = $one + $row['one'];
						$two = $two + $row['two'];
						$three = $three + $row['three'];
						$four = $four + $row['four'];
						$five = $five + $row['five'];
					}
					echo '<p>Unable to Judge : '.$zero.'</p>';
					echo '<p>Strongly Disagree : '.$one.'</p>';
					echo '<p>Disagree : '.$two.'</p>';
					echo '<p>Neutral : '.$three.'</p>';
					echo '<p>Agree : '.$four.'</p>';
					echo '<p>Strongly Agree : '.$zero.'</p>';
				}
			}
		?>
	<div>
		
	</div>
	</div>
	</div>	
</body>
</html>
