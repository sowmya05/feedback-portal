<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$result = mysql_query("SELECT * FROM disable");
	$row = mysql_fetch_array($result);
	if($row['enable']=='yes')
		$result = mysql_query("UPDATE disable SET enable = 'no' WHERE button = 'button'");
	else 
		$result = mysql_query("UPDATE disable SET enable = 'yes' WHERE button = 'button'");
	header('Location:admin_page.php');
?>
