<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	//echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$value = $_POST['select'];
	//echo $value;
	$value = $_POST['value'];
	$name = $_POST['text'];
	$_SESSION['value'] = $value;
	$_SESSION['name'] = $name;
	header('Location:feedback.php');
?>
