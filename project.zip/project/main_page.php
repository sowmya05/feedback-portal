<!DOCTYPE html>
<?php
session_start();
$mail = $_SESSION['mail'];
?>
<html>
	<head>
		<title>Feedback Portal</title>
		<link type="text/css" rel="stylesheet" href="page1.css"/>
		<script type="text/javascript" src="modernizr.custom.86080.js"></script>
	</head>

	<body class="page">
			<!-- background slideshow -->
        <ul class="cb-slideshow">
            <li><span>Image 01</span><div><h3>Ambitions </h3></div></li>
            <li><span>Image 02</span><div><h3>Targets </h3></div></li>
            <li><span>Image 03</span><div><h3>Aspects </h3></div></li>
            <li><span>Image 04</span><div><h3>Dreams </h3></div></li>
            <li><span>Image 05</span><div><h3>Goals </h3></div></li>
            <li><span>Image 06</span><div><h3>Hopes </h3></div></li>
        </ul>
			<!--content starts -->
		<div class="container">
			<div class="header">
				<h1>Feedback Portal</h1>
			</div>
			<div class="card">										
				<div class="ribbon"></div>
						<!-- Login form -->
					<div class="login">
						<h1>"Have your say"</h1>
						<p>Let's get started</p>
						<p>Enter your email id and password</p>
						<form action="login.php" method="POST">
							<input id="email" placeholder="Email" type="text" name="mail" required>
							<input id="password" placeholder="Password" type="password" name="pass" required> 
							<div class="radio">  
								<input id="Student" type="radio" value="student" name="des" checked="checked">  
								<label for="Student">Student</label>  
								<input id="Faculty" type="radio" value="faculty" name="des">  
								<label for="Faculty">Faculty</label> 
								<input id="Admin" type="radio" value="admin" name="des">  
								<label for="Admin">Admin</label>  
							</div>  
							<input id="submit" type="submit" value="Login"></input>
						</form>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>	

	<!-- php code for alert button on incorrect submission -->
<?php
	if($_SESSION['errors']== 1){ 
?>
<script type="text/javascript">
	alert('Incorrect webmail or password');
</script>
<?php 
	} 	
?>
	<!-- unsessting session variables -->
<?php
	if(isset($_SESSION['errors'])){
    		unset($_SESSION['errors']);
	} 
?>
