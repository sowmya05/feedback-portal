<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");

		/*session variables*/
	$code = $_SESSION['code'];
	$course = $_SESSION['course'];
	$mail = $_SESSION['mail'];
	$lab = $_SESSION['lab'];
	$tutorial = $_SESSION['tutorial'];

		/*finding out number of questions */
	$question[1]=0; $question[2]=0; $question[0]=0; 
	$result = mysql_query("SELECT * FROM course_questions");
	while($row=mysql_fetch_array($result)){$question[0]++;}
	$result = mysql_query("SELECT * FROM lab_questions");
	while($row=mysql_fetch_array($result)){$question[1]++;}
	$result = mysql_query("SELECT * FROM tutorial_questions");
	while($row=mysql_fetch_array($result)){$question[2]++;}

		/*retrieving answers stored by each user*/
	for($i=0;$i<3;$i++)
	{	
		$zero[$i]=0;$one[$i]=0;$two[$i]=0;$three[$i]=0;$four[$i]=0;$five[$i]=0;
		$sum[$i]=0;
		for($j=0;$j<$question[$i];$j++)
		{
			$a[$j][$i] = $_POST['a'.$j.''.$i.''];
			$sum[$i] = $sum[$i] + $a[$j][$i];
			if($a[$j][$i]==0) {$zero[$i]++;}
			else if($a[$j][$i]==1) {$one[$i]++;}
			else if($a[$j][$i]==2) {$two[$i]++;}
			else if($a[$j][$i]==3) {$three[$i]++;}
			else if($a[$j][$i]==4) {$four[$i]++;}
			else if($a[$j][$i]==5) {$five[$i]++;}
		}
		$comments[$i] = $_POST['comments'.$i.''];
		$avg[$i] = ($sum[$i]) / 5;
		
		/*storing averages in database for each user*/
		if($i==0)
		{
			$result = mysql_query("SELECT * FROM course_feedback WHERE course='$code' AND student='$mail'");
			if($row=mysql_fetch_array($result))
				{
					$result=mysql_query("UPDATE course_feedback SET avg=$avg[$i],zero=$zero[$i],one=$one[$i],two=$two[$i],three=$three[$i],four=$four[$i],five=$five[$i] WHERE course='$code' AND student='$mail'",$dbhandle);
				}
			else 	{
					$result = mysql_query("INSERT INTO course_feedback (course,course_name,student,avg,comments,zero,one,two,three,four,five) VALUES ('$code','$course','$mail',$avg[$i],'$comments[$i]',$zero[$i],$one[$i],$two[$i],$three[$i],$four[$i],$five[$i])",$dbhandle);
				}
		}
		else if($lab!=NULL && $i==1)	
		{
			$result = mysql_query("SELECT * FROM lab_feedback WHERE webmail='$faculty[$i]' AND course='$code' AND student='$mail'");
			if($row=mysql_fetch_array($result))
			{
				$result = mysql_query("UPDATE lab_feedback SET avg=$avg[$i],zero=$zero[$i],one=$one[$i],two=$two[$i],three=$three[$i],four=$four[$i],five=$five[$i] WHERE course='$code' AND student='$mail'",$dbhandle);
			}
			else
			{
				$result = mysql_query("INSERT INTO lab_feedback (course,course_name,student,avg,comments,zero,one,two,three,four,five) VALUES ('$code','$course','$mail',$avg[$i],'$comments[$i]',$zero[$i],$one[$i],$two[$i],$three[$i],$four[$i],$five[$i])",$dbhandle);
			}
		}
		
		else if($tutorial!=NULL && $i==2)	
		{
			$result = mysql_query("SELECT * FROM tutorial_feedback WHERE webmail='$faculty[$i]' AND course='$code' AND student='$mail'");
			if($row=mysql_fetch_array($result))
			{
				$result = mysql_query("UPDATE tutorial_feedback SET avg=$avg[$i],zero=$zero[$i],one=$one[$i],two=$two[$i],three=$three[$i],four=$four[$i],five=$five[$i] WHERE course='$code' AND student='$mail'",$dbhandle);
			}
			else
			{
				$result = mysql_query("INSERT INTO tutorial_feedback (course,course_name,student,avg,comments,zero,one,two,three,four,five) VALUES ('$code','$course','$mail',$avg[$i],'$comments[$i]',$zero[$i],$one[$i],$two[$i],$three[$i],$four[$i],$five[$i])",$dbhandle);
			}
		}
}

		/*update database for course-feedback*/
	$sum=0;
	$i=0;
	$result=mysql_query("SELECT * FROM course_feedback WHERE course='$code'");
	while($row=mysql_fetch_array($result))
	{
		$sum = $sum + $row['avg'];
		$i++;
	}
	$avg = $sum/$i;
	$result=mysql_query("SELECT * FROM course_avg WHERE course='$code'");
	if($row=mysql_fetch_array($result)){
		$result=mysql_query("UPDATE course_avg SET avg=$avg WHERE course='$code'");}
	else{
		$result=mysql_query("INSERT INTO course_avg (course,avg) VALUES ('$code',$avg)",$dbhandle);}
	
		/*update database for lab-feedback*/
	$sum=0;
	$i=0;
	$result=mysql_query("SELECT * FROM lab_feedback WHERE course='$code'");
	while($row=mysql_fetch_array($result))
	{
		$sum = $sum + $row['avg'];
		$i++;
	}
	$avg = $sum/$i;
	$result=mysql_query("SELECT * FROM lab_avg WHERE course='$code'");
	if($row=mysql_fetch_array($result)){
		$result=mysql_query("UPDATE lab_avg SET avg=$avg WHERE course='$code'");}
	else{
		$result=mysql_query("INSERT INTO lab_avg (course,avg) VALUES ('$code',$avg)",$dbhandle);}
	
		/*update database for tutorial-feedback*/
	$sum=0;
	$i=0;
	$result=mysql_query("SELECT * FROM course_feedback WHERE course='$code'");
	while($row=mysql_fetch_array($result))
	{
		$sum = $sum + $row['avg'];
		$i++;
	}
	$avg = $sum/$i;
	$result=mysql_query("SELECT * FROM tutorial_avg WHERE course='$code'");
	if($row=mysql_fetch_array($result)){
		$result=mysql_query("UPDATE tutorial_avg SET avg=$avg WHERE course='$code'");}
	else{
		$result=mysql_query("INSERT INTO tutorial_avg (course,avg) VALUES ('$code',$avg)",$dbhandle);}
	
	header('Location: http://localhost/project/student/student_page.php');
?>
