<!DOCTYPE html>
<?php
	session_start();
	$mail = $_SESSION['mail'];
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$course=$_POST['course'];
	$code=$_POST['code'];
	$faculty1=$_POST['faculty1'];
	$faculty2=$_POST['faculty2'];
	$_SESSION['course']=$course;
	$_SESSION['code']=$code;
	$_SESSION['faculty1']=$faculty1;
	$_SESSION['faculty2']=$faculty2;
	$result = mysql_query("SELECT * FROM courses WHERE course='$code'");
	$row=mysql_fetch_row($result);
	$faculty3=$row['faculty3'];
	$faculty4=$row['faculty4'];
	$_SESSION['faculty3']=$faculty3;
	$_SESSION['faculty4']=$faculty4;
	$result=mysql_query("SELECT * FROM faculty WHERE webmail = '$faculty1'");
	$row=mysql_fetch_array($result);
	$faculty[1]=$row['faculty'];
	$result=mysql_query("SELECT * FROM faculty WHERE webmail='$faculty2'");
	$row=mysql_fetch_array($result);
	$faculty[2]=$row['faculty'];
	$result = mysql_query("SELECT * FROM courses WHERE course = '$code'");
	$row = mysql_fetch_array($result);
	$lab = $row['lab'];
	$_SESSION['lab']=$lab;
	$tutorial = $row['tutor'];
	$_SESSION['tutorial'] = $tutorial;
	$faculty3 = $row['faculty3'];
	$result=mysql_query("SELECT * FROM faculty WHERE webmail='$faculty3'");
	$row=mysql_fetch_array($result);
	$faculty[3]=$row['faculty'];
	$faculty4 = $row['faculty4'];
	$result=mysql_query("SELECT * FROM faculty WHERE webmail='$faculty4'");
	$row=mysql_fetch_array($result);
	$faculty[4]=$row['faculty'];
?>
<html>
<head>
	<title>Feedback Portal</title>
		<link type="text/css" rel="stylesheet" href="page2.css"/>
		<link type="text/css" rel="stylesheet" href="tab.css"/>
		<script src="modernizr.custom.js"></script>
		<script type="text/javascript" src="modernizr.custom.86080.js"></script>
		<script src="jquery.min.js"></script>
</head>
<body class="page">
	<ul class="cb-slideshow">
            <li><span>Image 01</span></li>
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
            <li><span>Image 04</span></li>
            <li><span>Image 05</span></li>
            <li><span>Image 06</span></li>
        </ul>
	<div class="container">
		<div class="header">
			<h1>Feedback Portal</h1>
			
			<button onclick="location.href='student_page.php'">DONE!</button>
				<div class="form">
				<ul id="tabs">
				      <li><a href="#" name="#tab1">Course Feedback</a></li>
				      <li><a href="#" name="#tab2">Faculty Feedback</a></li>
				  </ul>

				  <div id="content">
				      <div id="tab1">
					<form action="enter_feedback.php" method="POST">
						<h2>About course: </h2>
						<h4><?php echo $code; echo' : '; echo $course; ?> </h4>
						<?php 
							$result = mysql_query("SELECT * FROM course_questions");
							$i=0; $j=0;
							while($row=mysql_fetch_array($result))
							{
							 $j++;
							 echo '<div><p>'.$j.'. '.$row["question"].'</p>
							 <input type=radio id="1'.$j.''.$i.'" group="a'.$j.''.$i.'" value=0 name="a'.$j.''.$i.'" checked ="checked"><label for="1a'.$j.''.$i.'">Unable to judge</label>
					<input type=radio id="2a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=1 name="a'.$j.''.$i.'"><label for="2a'.$j.''.$i.'">Strongly Disagree</label>
					<input type=radio id="3a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=2 name="a'.$j.''.$i.'"><label for="3a'.$j.''.$i.'">Disagree</label>
					<input type=radio id="4a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=3 name="a'.$j.''.$i.'"><label for="4a'.$j.''.$i.'">Neutral</label>
					<input type=radio id="5a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=4 name="a'.$j.''.$i.'"><label for="5a'.$j.''.$i.'">Agree</label>
					<input type=radio id="6a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=5 name="a'.$j.''.$i.'"><label for="6a'.$j.''.$i.'">Strongly Agree</label>
							</div><div>&nbsp;</div>';
							}
							echo '<p>Any suggestions for the course:</p>
					<textarea name="comments['.$i.']" cols="70" rows="4"></textarea>';							 
						if($lab)
							{ echo '<h4>About Lab</h4>'; 
							$i=1; $j=0;
							$result = mysql_query("SELECT * FROM lab_questions");
							while($row=mysql_fetch_array($result))
							{
							 $j++;
							 echo '<div><p>'.$j.'. '.$row["question"].'</p>
							 <input type=radio id="1'.$j.''.$i.'" group="a'.$j.''.$i.'" value=0 name="a'.$j.''.$i.'" checked ="checked"><label for="1a'.$j.''.$i.'">Unable to judge</label>
					<input type=radio id="2a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=1 name="a'.$j.''.$i.'"><label for="2a'.$j.''.$i.'">Strongly Disagree</label>
					<input type=radio id="3a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=2 name="a'.$j.''.$i.'"><label for="3a'.$j.''.$i.'">Disagree</label>
					<input type=radio id="4a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=3 name="a'.$j.''.$i.'"><label for="4a'.$j.''.$i.'">Neutral</label>
					<input type=radio id="5a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=4 name="a'.$j.''.$i.'"><label for="5a'.$j.''.$i.'">Agree</label>
					<input type=radio id="6a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=5 name="a'.$j.''.$i.'"><label for="6a'.$j.''.$i.'">Strongly Agree</label>
							</div><div>&nbsp;</div>';							 
							}
								echo '<p>Any suggestions for the Lab:</p>
					<textarea name="comments['.$i.']" cols="70" rows="4">
					</textarea>';						
							 }
						if($tutorial)
							{ echo '<h4>About Tutorial</h4>'; 
							$i=2; $j=0;
							$result = mysql_query("SELECT * FROM lab_questions");
							while($row=mysql_fetch_array($result))
							{
							 $j++;
							 echo '<div><p>'.$j.'. '.$row["question"].'</p>
							 <input type=radio id="1'.$j.''.$i.'" group="a'.$j.''.$i.'" value=0 name="a'.$j.''.$i.'" checked ="checked"><label for="1a'.$j.''.$i.'">Unable to judge</label>
					<input type=radio id="2a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=1 name="a'.$j.''.$i.'"><label for="2a'.$j.''.$i.'">Strongly Disagree</label>
					<input type=radio id="3a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=2 name="a'.$j.''.$i.'"><label for="3a'.$j.''.$i.'">Disagree</label>
					<input type=radio id="4a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=3 name="a'.$j.''.$i.'"><label for="4a'.$j.''.$i.'">Neutral</label>
					<input type=radio id="5a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=4 name="a'.$j.''.$i.'"><label for="5a'.$j.''.$i.'">Agree</label>
					<input type=radio id="6a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=5 name="a'.$j.''.$i.'"><label for="6a'.$j.''.$i.'">Strongly Agree</label>
							</div><div>&nbsp;</div>';							 
							} 
							echo '<p>Any suggestions for the tutorial:</p>
					<textarea name="comments['.$i.']" cols="70" rows="4"></textarea>';
							}
						?>
					<p><input type="submit" value ="submit"></p>					
					</form>	
				       </div>
				<div id="tab2">
				<form action="faculty_feedback.php" method="POST">
					<?php
					   $k=1;$i=2;
						while($faculty[$k]){
							echo '<h4>'.$faculty[$k].'</h4>';
							$i++; $j=0;
							$result = mysql_query("SELECT * FROM instructor_questions");
							while($row=mysql_fetch_array($result))
							{
							 $j++;
							 echo '<div><p>'.$j.'. '.$row["question"].'</p>
							 <input type=radio id="1'.$j.''.$i.'" group="a'.$j.''.$i.'" value=0 name="a'.$j.''.$i.'" checked ="checked"><label for="1a'.$j.''.$i.'">Unable to judge</label>
					<input type=radio id="2a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=1 name="a'.$j.''.$i.'"><label for="2a'.$j.''.$i.'">Strongly Disagree</label>
					<input type=radio id="3a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=2 name="a'.$j.''.$i.'"><label for="3a'.$j.''.$i.'">Disagree</label>
					<input type=radio id="4a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=3 name="a'.$j.''.$i.'"><label for="4a'.$j.''.$i.'">Neutral</label>
					<input type=radio id="5a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=4 name="a'.$j.''.$i.'"><label for="5a'.$j.''.$i.'">Agree</label>
					<input type=radio id="6a'.$j.''.$i.'" group="a'.$j.''.$i.'" value=5 name="a'.$j.''.$i.'"><label for="6a'.$j.''.$i.'">Strongly Agree</label>
							</div><div>&nbsp;</div>';
						}
						$k++;
						echo '<p>Any suggestions for the faculty:</p>
					<textarea name="comments['.$i.']" cols="70" rows="4" value=""></textarea><div>&nbsp;</div>';
						}
						echo '<p><input type="submit" value ="submit"></p>';
					?>
						
					</form>					
				      </div> 
				    	
				 </div>
					<script src="jquery-1.7.2.min.js"></script>
					<script type="text/javascript" src="tab.js"></script>
				</div>
			</div>
		</div>
	</body>
</html>
