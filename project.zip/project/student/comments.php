<?php
	session_start();
	$mail = $_SESSION['mail'];
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");

		/*POST variables*/
	$code=$_POST['code'];
	$faculty=$_POST['faculty'];
	$name=$_POST['c'];
	$comments=$_POST['value'];
	$ana = $_POST['ana'];
	echo $ana;
	$result = mysql_query("INSERT INTO comments (from_mail,to_mail,value,comment,anonymous) VALUES ('$mail','$faculty','$name','$comments','$ana')",$dbhandle);
	if($result)
		{
			header('Location: http://localhost/project/student/student_page.php');
		}
?>
