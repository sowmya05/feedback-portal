<!DOCTYPE html>
<?php
	session_start();
	$mail = $_SESSION['mail'];			//getting session variable
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$result = mysql_query("SELECT * FROM students WHERE webmail = '$mail'");
	$row = mysql_fetch_array($result);
	$sem = $row['sem'];				//getting sem and department from database to get courses
	$dep = $row['department'];
	$result = mysql_query("SELECT * FROM courses WHERE sem = '$sem' AND department = '$dep'");	//retrieve courses 
	$i=0;
	while($row = mysql_fetch_array($result))
	{
		/* retrieve respective faculties and their names */
		$faculty1_mail[$i] = $row['faculty1'];
		$result1 = mysql_query("SELECT * FROM faculty WHERE webmail = '$faculty1_mail[$i]'");
		$row1 = mysql_fetch_array($result1);
		$faculty1[$i] = $row1['faculty'];
		$faculty2_mail[$i] = $row['faculty2'];
		$result1 = mysql_query("SELECT * FROM faculty WHERE webmail = '$faculty2_mail[$i]'");
		$row1 = mysql_fetch_array($result1);
		$faculty2[$i] = $row1['faculty'];
		$code[$i] = $row['code'];
		$name[$i] = $row['name'];
		$result1 = mysql_query("SELECT * FROM course_feedback WHERE course='$code[$i]' AND student='$mail'");
		$row1 = mysql_fetch_array($result1);
		/* storing avg given by the student in previous session */
		$course_avg[$i] = $row1['avg'] * 20;
		$result1 = mysql_query("SELECT * FROM faculty_feedback WHERE webmail='$faculty1_mail[$i]' AND course='$code[$i]' AND 			student='$mail'");
		$row1 = mysql_fetch_array($result1);
		$faculty1_avg[$i] = $row1['avg'] * 20;
		if($faculty2_mail[$i])
		{
			$result1 = mysql_query("SELECT * FROM faculty_feedback WHERE webmail='$faculty2_mail[$i]' AND course='$code[$i]' AND 				student='$mail'");
			$row1 = mysql_fetch_array($result1);
			$faculty2_avg[$i] = $row1['avg'] * 20;
		}
		$i = $i + 1;
	}
?>

<html>
	<head>
		<title>Feedback Portal</title>
		<link type="text/css" rel="stylesheet" href="page2.css"/>
		<link rel="stylesheet" type="text/css" href="default.css" />
		<link rel="stylesheet" type="text/css" href="component.css" />
		<script src="modernizr.custom.js"></script>
		<script type="text/javascript" src="modernizr.custom.86080.js"></script>
		<script src="jquery.min.js"></script>
		<!-- script for comment box -->
		<script>
			$(document).ready(function(){
  				$("#0").click(function(){
    					$("#0d").toggle();
  				});
				$("#1").click(function(){
    					$("#1d").toggle();
  				});
				$("#2").click(function(){
    					$("#2d").toggle();
  				});
				$("#3").click(function(){
    					$("#3d").toggle();
  				});
			});
		</script>
	<?php 
		$query = mysql_query("SELECT * FROM disable");
		$row = mysql_fetch_array($query);
		$get = $row['enable'];
	?>
	</head>

	<body class="page">
	<!-- background slideshow -->
        <ul class="cb-slideshow">
            <li><span>Image 01</span></li>
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
            <li><span>Image 04</span></li>
            <li><span>Image 05</span></li>
            <li><span>Image 06</span></li>
        </ul>

	<div class="container">
		<div class="header">
			<h1>Feedback Portal</h1>
			<button onclick="location.href='../main_page.php'">Logout</button>
			<ul class="grid cs-style-4">
			<?php
				/* displaying courses */
				for($j=0;$j<$i;$j++)
				{
				echo '
				<li>
					<figure>
						<div><img src="'.$j.'.png" alt="img0'.$j.'" id="'.$j.'"></div>
						<figcaption>
							<h4>'.$code[$j].' : '.$name[$j].'</h4>

							<div class="rating_bar">
							    <div  class="rating" style="width:'.$course_avg[$j].'%;">
							    </div>
							</div>
							<div class="faculty">  
								<p>'.$faculty1[$j].'</p>
							<div class="rating_bar">
							    <div  class="rating" style="width:'.$faculty1_avg[$j].'%;">
							    </div>
							</div> ';
							if($faculty2[$j])
							{
								echo'<p>'.$faculty2[$j].'</p>
								<div class="rating_bar">
							    		<div  class="rating" style="width:'.$faculty2_avg[$j].'%;">
							    		</div>
								</div>';
							}   
							echo '</div>

							<form action="feedback_form.php" method="POST">
								<input type="text" value="'.$code[$j].'" name="code" hidden="true">
								<input type="text" value="'.$name[$j].'" name="course" hidden="true">
								<input type="text" value="'.$faculty1_mail[$j].'" name="faculty1" hidden="true">';
								if($faculty2[$j]){ echo'
								<input type="text" value="'.$faculty2_mail[$j].'" name="faculty2" hidden="true">'; }						
								echo '
								<input type="submit" value="give feedback" class="give-feedback pure-button"'; if($get=='no') echo 'disabled="disabled"'; echo '>
							</form>  
						</figcaption>
					</figure>
				</li>
				<div id="'.$j.'d" hidden="true" class="cont">
					<form action="comments.php" method="POST">
						<div class="radio">
							<label>
							<input type=radio id="c1'.$j.'" name="c" value="complaint" group="1" checked="checked">
							<img src="complaint.gif" class"icon"/>
							</label>
							<label>
							<input type=radio id="c2'.$j.'" name="c" value="compliment" group="1">
							<img src="compliment.png" />							
							</label>
							<label>				
							<input type=radio id="c3'.$j.'" name="c" value="question" group="1">
							<img src="question.png" />
							</label>
							<label>				
							<input type=radio id="c4'.$j.'" name="c" value="idea" group="1">
							<img src="idea.png" />
							</label>		
							<input type="text" value="'.$code[$j].'" name="code" hidden="true">
							<input type="radio" value="'.$faculty1_mail[$j].'" name="faculty" id="c5'.$j.'" checked="checked"><label for="c5'.$j.'">'.$faculty1[$j].'</label>';
							if($faculty2[$j]){ echo'
							<input type="radio" value="'.$faculty2_mail[$j].'" name="faculty" id="c6'.$j.'" label=""<label for="c6'.$j.'">'.$faculty2[$j].'</label>'; }		
				echo'	                <input type="checkbox" id="c6'.$j.'" name="ana" value="anonymous"><label for="c6'.$j.'">Anonymous</label>	
						</div>
						<div>
							<textarea class="text" name="value" cols="70" rows="4"></textarea>
						</div>
						<div>
							<input type=submit value="POST">
						</div>
					</form>
				</div>';
				}
				?>
			</ul>
		</div><!-- /container -->
		<script src="toucheffects.js"></script>
	</body>
</html>
