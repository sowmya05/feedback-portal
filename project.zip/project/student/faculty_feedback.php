<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");

		/*session variables*/
	$faculty[3] = $_SESSION['faculty1'];
	$faculty[4] = $_SESSION['faculty2'];
	$faculty[5] = $_SESSION['faculty3'];
	$faculty[6] = $_SESSION['faculty4'];
	
	$code = $_SESSION['code'];
	$course = $_SESSION['course'];
	$mail = $_SESSION['mail'];

		/*finding out faculty name*/
	for($i=3;$i<7;$i++)
	{
		$result=mysql_query("SELECT * FROM faculty WHERE webmail='$faculty[$i]'");	
		$row=mysql_fetch_array($result);
		$faculty_name[$i]=$row['faculty'];
	}
	
		/*finding out number of questions */
	$question=0;  
	$result = mysql_query("SELECT * FROM instructor_questions");
	while($row=mysql_fetch_array($result)){$question++;}

		/*retrieving answers stored by each user*/
	for($i=3;$i<7;$i++)
	{
		$zero[$i]=0;$one[$i]=0;$two[$i]=0;$three[$i]=0;$four[$i]=0;$five[$i]=0;		
		$sum[$i]=0;
		for($j=0;$j<=$question;$j++)
		{
			$a[$j][$i] = $_POST['a'.$j.''.$i.''];
			$sum[$i] = $sum[$i] + $a[$j][$i];
			
			if($a[$j][$i]==0) {$zero[$i]++;}
			else if($a[$j][$i]==1) {$one[$i]++;}
			else if($a[$j][$i]==2) {$two[$i]++;}
			else if($a[$j][$i]==3) {$three[$i]++;}
			else if($a[$j][$i]==4) {$four[$i]++;}
			else if($a[$j][$i]==5) {$five[$i]++;}
		}
		$comments[$i] = $_POST['comments'.$i.''];
		$avg[$i] = ($sum[$i]) / ($question);

		/*storing averages in database for each user*/
		if($faculty[$i])	
		{
			$result = mysql_query("SELECT * FROM faculty_feedback WHERE webmail='$faculty[$i]' AND course='$code' AND student='$mail'");
			
			if($row=mysql_fetch_array($result))
			{
		
				$result = mysql_query("UPDATE faculty_feedback SET avg=$avg[$i],zero=$zero[$i],one=$one[$i],two=$two[$i],three=$three[$i],four=$four[$i],five=$five[$i],comments='$comments[$i]' WHERE webmail='$faculty[$i]' AND course='$code' AND student='$mail'",$dbhandle);
			
			}
			else
			{
				$result = mysql_query("INSERT INTO faculty_feedback (faculty_name,webmail,student,avg,comments,course,zero,one,two,three,four,five) VALUES ('$faculty_name[$i]','$faculty[$i]','$mail',$avg[$i],'$comments[$i]','$code',$zero[$i],$one[$i],$two[$i],$three[$i],$four[$i],$five[$i])",$dbhandle);
			}
		}
	}

		
		/*update database for faculty feedback*/
	for($j=3;$j<7;$j++)
	{
		$sum=0;
		$i=0;
		$x = $faculty[$j];
		$result=mysql_query("SELECT * FROM faculty_feedback WHERE course='$code' AND webmail='$x' ");
		while($row=mysql_fetch_array($result))
		{
			$sum = $sum + $row['avg'];
			$i++;
		}
		$avg = $sum/$i;
		$result=mysql_query("SELECT * FROM faculty_avg WHERE webmail='$x' AND course='$code'");
		if($row=mysql_fetch_array($result)){
			$result=mysql_query("UPDATE faculty_avg SET avg=$avg WHERE webmail='$x' AND course='$code'",$dbhandle);}
		else{
			$result=mysql_query("INSERT INTO faculty_avg (webmail,course,avg) VALUES ('$x','$code',$avg)",$dbhandle);}
		
	}

		/*faculty feedback for all courses*/
	for($j=3;$j<7;$j++)
	{
		$sum=0;
		$i=0;
		$x = $faculty[$j];
		$result=mysql_query("SELECT * FROM faculty_avg WHERE webmail='$x' ");
		while($row=mysql_fetch_array($result))
		{
			$sum = $sum + $row['avg'];
			$i++;
		}
		$avg = $sum/$i;
		$year = 2014;
		$result=mysql_query("SELECT * FROM faculty_total_avg WHERE webmail='$x'");
		if($row=mysql_fetch_array($result)){
			$result=mysql_query("UPDATE faculty_total_avg SET avg=$avg WHERE webmail='$x'",$dbhandle);}
		else{
			$result=mysql_query("INSERT INTO faculty_total_avg (webmail,avg) VALUES ('$x',$avg)",$dbhandle);}
		$result=mysql_query("SELECT * FROM faculty_year WHERE webmail='$x' AND year=$year");
		if($row=mysql_fetch_array($result)){
			
			$result=mysql_query("UPDATE faculty_year SET avg=$avg WHERE webmail='$x' AND year=$year",$dbhandle);}
		else{
			$result=mysql_query("INSERT INTO faculty_year (webmail,year,avg) VALUES ('$x',$year,$avg)",$dbhandle);}
		
	}
	header('Location: http://localhost/project/student/student_page.php');
?>
