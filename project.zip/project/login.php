<?php
	session_start();
	$username = "root";
	$password = "mysql";
	$hostname = "localhost"; 
		//connection to the database
	$dbhandle = mysql_connect($hostname, $username, $password)
  		or die("Unable to connect to MySQL");
	echo "Connected to MySQL<br>";
	$selected=mysql_select_db("working",$dbhandle)
 		or die("could not select working");
	$mail = $_POST['mail'];
	$_SESSION['mail']=$mail;	//creating a session variable for mail
	$pass = $_POST['pass'];
	$des = $_POST['des'];

		/*checking type of login*/

	//student login
	if($des == "student")
	{
		$result = mysql_query("SELECT * FROM students where webmail='$mail' AND password='$pass'");
		$row = mysql_fetch_array($result);
		if($row)
		{
			header("Location: http://localhost/project/student/student_page.php");
		}
		else{
 			$_SESSION['errors'] = 1;
    			session_write_close();
    			header("Location: http://localhost/project/main_page.php");
    			exit;
 		}
	}
	
	//faculty login
	else if($des == "faculty")
	{
		$result = mysql_query("SELECT * FROM faculty where webmail='$mail' AND password='$pass'");
		$row = mysql_fetch_array($result);
		if($row)
		{
			header("Location: http://localhost/project/faculty/faculty_page.php");
		}
		else{
 			$_SESSION['errors'] = 1;
    			session_write_close();
    			header("Location: http://localhost/project/main_page.php");
    			exit;
 		}
	}
	
	//admin login
	else if($des == "admin")
	{
		$result = mysql_query("SELECT * FROM admin where webmail='$mail' AND password='$pass'");
		$row = mysql_fetch_array($result);
		if($row)
		{
			header("Location: http://localhost/project/admin/admin_page.php");
		}
		else{
 			$_SESSION['errors'] = 1;
    			session_write_close();
    			header("Location: http://localhost/project/main_page.php");
    			exit;
 		}
	}

?>




