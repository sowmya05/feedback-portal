<!DOCTYPE html>
<?php
session_start();
$username = "root";
$password = "mysql";
$hostname = "localhost"; 
//connection to the database
$dbhandle = mysql_connect($hostname, $username, $password)
  or die("Unable to connect to MySQL");
$selected=mysql_select_db("working",$dbhandle)
 or die("could not select working");
$mail = $_SESSION['mail'];
$result = mysql_query("SELECT * FROM faculty_total_avg WHERE webmail = '$mail'");
$row = mysql_fetch_array($result);
$total_avg = $row['avg'] * 20;
$result = mysql_query("SELECT * FROM faculty WHERE webmail = '$mail'");
$i=0;
while($row = mysql_fetch_array($result))
{
$name = $row['faculty'];
$course[$i] = $row['course'];
$result1 = mysql_query("SELECT * FROM faculty_avg WHERE webmail = '$mail' AND course = '$course[$i]'");
$row1=mysql_fetch_array($result1);
$avg[$i] = $row1['avg'] * 20;
$i++;
}

?>
<html>
	<head>
		<title>Feedback Portal</title>
		<link type="text/css" rel="stylesheet" href="page2.css"/>
		<link type="text/css" rel="stylesheet" href="tab.css"/>
		<script type="text/javascript" src="modernizr.custom.86080.js"></script>
		<script type="text/javascript" src="jquery.min.js"></script>
		<script type="text/javascript" src="graph.js"></script>
	    	<script src="highcharts.js"></script>
        	<script src="exporting.js"></script>
	</head>
	<body class="page">
		<ul class="cb-slideshow">
		    <li><span>Image 01</span><div></div></li>
		    <li><span>Image 02</span><div></div></li>
		    <li><span>Image 03</span><div></div></li>
		    <li><span>Image 04</span><div></div></li>
		    <li><span>Image 05</span><div></div></li>
		    <li><span>Image 06</span><div></div></li>
		</ul>
		<div class="container">
			<div class="header">
				<h1>Feedback Portal</h1>
				<button onclick="location.href='../main_page.php'">Logout</button>
				<h3>Welcome : <?php echo $name; ?>    <div class="rating_bar">
							    <div  class="rating" style="width:<?php echo $total_avg; ?>%;">
							    </div>
							</div></h3>
			</div>
			<div class="header" id="courses">
				<h2>Your courses: </h2>
				<?php $i=0; foreach ($course as $value) {
					echo '<p>'.$value.'</p>
					<div class="rating_bar">
							    <div  class="rating" style="width:'.$avg[$i].'%;">
							    </div>
							</div>';
					$i++;
				}
				?>
			</div>
			
		</div>
			<div id="graph" ></div>
		<div id="inter">
		<ul id="tabs">
		      <li><a href="#" name="#tab1">Compliments</a></li>
		      <li><a href="#" name="#tab2">Complaints</a></li>
			<li><a href="#" name="#tab3">Ideas</a></li>
			<li><a href="#" name="#tab4">Question</a></li>
		  </ul>

		  <div id="content">
		      <div id="tab1">
			  <?php
				
				$result=mysql_query("SELECT * FROM comments WHERE to_mail='$mail' AND value='compliment'");
				while($row=mysql_fetch_array($result)){
					if($row['anonymous']!='anonymous')
						{
							echo $from_mail; echo '    :    ';
						}
					else echo 'Anonymous   :     ';
					echo $row['comment'];
					echo '<p></p>';
				} 
			?>   
		      </div>
		      <div id="tab2">
			  <?php
				
				$result=mysql_query("SELECT * FROM comments WHERE to_mail='$mail' AND value='complaint'");
				while($row=mysql_fetch_array($result)){
					if($row['anonymous']!='anonymous')
						{
							echo $row['from_mail']; echo '    :    ';
						}
					else echo 'Anonymous   :     ';
					echo $row['comment']; echo '<p></p>';
				} 
			?>   
		      </div> 
		    	<div id="tab3">
			   <?php
				
				$result=mysql_query("SELECT * FROM comments WHERE to_mail='$mail' AND value='idea'");
				while($row=mysql_fetch_array($result)){
					if($row['anonymous']!='anonymous')
						{
							echo $row['from_mail'];
							echo '    :    ';
						}
					else echo 'Anonymous   :     ';
					echo $row['comment'];
				echo '<p></p>';
				} 
			?>   
		      </div> 
			<div id="tab4">
			    <?php
				
				$result=mysql_query("SELECT * FROM comments WHERE to_mail='$mail' AND value='question'");
				while($row=mysql_fetch_array($result)){
					if($row['anonymous']!='anonymous')
						{
							echo $row['from_mail']; echo '    :    ';
						}
					else echo 'Anonymous   :     ';
					echo $row['comment']; echo '<p></p>';
				} 
			?>   
		      </div> 
		  </div>
			<script src="jquery-1.7.2.min.js"></script>
	<script type="text/javascript" src="tab.js"></script>
		</div>

		<div id="feedback">
			</div>
	</body>
</html>
