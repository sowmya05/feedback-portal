<!DOCTYPE html>
<html>
	<head>
		<title>Feedback Portal</title>
			<link type="text/css" rel="stylesheet" href="prof.css"/>
		    <script type="text/javascript" src="modernizr.custom.86080.js"></script>
	</head>
	<body class="page">
        <ul class="cb-slideshow">
            <li><span>Image 01</span></li>
            <li><span>Image 02</span></li>
            <li><span>Image 03</span></li>
            <li><span>Image 04</span></li>
            <li><span>Image 05</span></li>
            <li><span>Image 06</span></li>
        </ul>
		<div class="container">
			<div class="header">
				<h1>Feedback Portal</h1>
				<input id="submit" type="submit" value="Logout"></input>
			</div>
			<div class="content">
				<div class="left">
					<h1 class="name">Name of the prof</h1>
					<div class="left_objects">
						<img src="1.jpg">
					</div>
				</div>
				<div class="right">
					<div class="rt"></div>
					<div class="right_articles">
					</div>
				</div>
			</div>
		</div>	
	</body>
</html>
